export function isStoreProduct(product) {
  return (product?.taxType || product?.tax_type) === 'tax_included';
}

export function isBuyoutOnlyProduct(product) {
  const buyoutPrice = getBuyoutPrice(product);
  return Boolean(product?.buyoutOnly || product?.buyout_only) && buyoutPrice > 0;
}

export function getBuyoutPrice(product) {
  const directBuyoutPrice = Number(product?.buyoutPrice ?? product?.buyout_price ?? 0);
  if (Number.isFinite(directBuyoutPrice) && directBuyoutPrice > 0) {
    return Math.floor(directBuyoutPrice);
  }
  if (product?.buyoutOnly || product?.buyout_only) {
    const currentPrice = Number(product?.currentPrice ?? product?.current_price ?? 0);
    if (Number.isFinite(currentPrice) && currentPrice > 0) return Math.floor(currentPrice);
  }
  return 0;
}

export function getBuyoutSubmitPrice(product) {
  return getBuyoutPrice(product);
}

export function getSubmitTaxType(product, storeBidPriceMode) {
  if (!isStoreProduct(product)) return product?.taxType || product?.tax_type || 'tax_zero';
  return 'tax_included';
}

export function getActualBidPrice(maxPrice, product, storeBidPriceMode) {
  const value = Number(maxPrice || 0);
  if (!Number.isFinite(value) || value <= 0) return 0;
  if (isStoreProduct(product) && storeBidPriceMode === 'tax_before') {
    return Math.ceil(value * 1.1);
  }
  return Math.floor(value);
}

export function getSubmitMaxPrice(maxPrice, product, storeBidPriceMode) {
  if (isStoreProduct(product) && storeBidPriceMode === 'tax_before') {
    return getActualBidPrice(maxPrice, product, storeBidPriceMode);
  }
  const value = Number(maxPrice || 0);
  return Number.isFinite(value) && value > 0 ? Math.floor(value) : 0;
}

// current_price 来自 proxy.js 抓的 Yahoo HTML `price` 字段，始终是税前口径
// （商城商品页面显示的"現在 ××円（税込）"是税后，但 HTML 里另存了 price=税前 + taxinPrice=税后）。
// effectiveMaxPrice / user_max_price 是税后口径，要跟它比就把税前 current_price ×1.1 加税。
export function getComparableCurrentPrice(product) {
  const value = Number(product?.currentPrice ?? product?.current_price ?? 0);
  if (!Number.isFinite(value) || value <= 0) return 0;
  if (!isStoreProduct(product) || value < 10) return Math.floor(value);
  return Math.floor(value * 1.1);
}

export function getYahooMinimumBidIncrement(currentTaxExcludedPrice) {
  const value = Number(currentTaxExcludedPrice || 0);
  if (!Number.isFinite(value) || value <= 0) return 0;
  if (value < 1000) return 10;
  if (value < 5000) return 100;
  if (value < 10000) return 250;
  if (value < 50000) return 500;
  return 1000;
}

export function getRequiredTaxExcludedBidPrice(product) {
  const currentPrice = Number(product?.currentPrice ?? product?.current_price ?? 0);
  if (!Number.isFinite(currentPrice) || currentPrice <= 0) return 0;
  const bidCount = Number(product?.bidCount ?? product?.bid_count ?? 0);
  const increment = Number.isFinite(bidCount) && bidCount > 0
    ? getYahooMinimumBidIncrement(currentPrice)
    : 0;
  return Math.floor(currentPrice + increment);
}

export function isSubmitTaxExcludedPriceAtLeastRequiredBid(submitTaxExcludedPrice, product) {
  const required = getRequiredTaxExcludedBidPrice(product);
  if (required <= 0) return true;
  return Number(submitTaxExcludedPrice || 0) >= required;
}

export function getMinimumBidComparableInputPrice({ inputYenPrice, submitTaxExcludedPrice, product, storeBidPriceMode }) {
  if (isStoreProduct(product)) {
    return Math.floor(Number(inputYenPrice || 0));
  }
  return Math.floor(Number(submitTaxExcludedPrice || 0));
}

export function getMinimumBidInputRequirement(product, storeBidPriceMode) {
  const currentTaxExcludedPrice = Number(product?.currentPrice ?? product?.current_price ?? 0);
  if (!Number.isFinite(currentTaxExcludedPrice) || currentTaxExcludedPrice <= 0) {
    return { currentPrice: 0, increment: 0, requiredPrice: 0, currentLabel: '当前价' };
  }

  const bidCount = Number(product?.bidCount ?? product?.bid_count ?? 0);
  const increment = Number.isFinite(bidCount) && bidCount > 0
    ? getYahooMinimumBidIncrement(currentTaxExcludedPrice)
    : 0;
  const storeProduct = isStoreProduct(product);
  const useTaxIncludedInput = storeProduct && storeBidPriceMode === 'tax_after';
  const requiredTaxExcludedPrice = Math.floor(currentTaxExcludedPrice + increment);
  const currentPrice = useTaxIncludedInput
    ? getComparableCurrentPrice(product)
    : Math.floor(currentTaxExcludedPrice);
  const requiredPrice = useTaxIncludedInput
    ? Math.ceil((requiredTaxExcludedPrice * 1.1) - 1e-6)
    : requiredTaxExcludedPrice;
  const displayIncrement = Math.max(0, requiredPrice - currentPrice);
  const currentLabel = storeProduct
    ? (useTaxIncludedInput ? '当前税后价' : '当前税前价')
    : '当前价';

  return {
    currentPrice,
    increment: displayIncrement,
    requiredPrice,
    currentLabel
  };
}

export function isSubmitMaxPriceAboveCurrentPrice(submitMaxPrice, product) {
  const currentPrice = getComparableCurrentPrice(product);
  if (currentPrice <= 0) return true;
  return Number(submitMaxPrice || 0) > currentPrice;
}

export function getBidInputYenPrice(inputAmount, currency = 'jpy', websiteRate = 0) {
  const value = Number(inputAmount || 0);
  if (!Number.isFinite(value) || value <= 0) return 0;
  if (currency !== 'cny') return Math.floor(value);
  const rate = Number(websiteRate || 0);
  if (!Number.isFinite(rate) || rate <= 0) return 0;
  return Math.floor(value / rate);
}

export function formatCnyAmount(value) {
  const amount = Number(value || 0);
  if (!Number.isFinite(amount) || amount <= 0) return '0';
  const rounded = Number(amount.toFixed(2));
  return Number.isInteger(rounded) ? String(rounded) : String(rounded);
}

export function getYenAsCnyAmount(yenAmount, websiteRate = 0) {
  const yen = Number(yenAmount || 0);
  const rate = Number(websiteRate || 0);
  if (!Number.isFinite(yen) || yen <= 0 || !Number.isFinite(rate) || rate <= 0) return 0;
  return Number((yen * rate).toFixed(2));
}

export function getActualBidDisplay(inputAmount, product, storeBidPriceMode, currency = 'jpy', websiteRate = 0) {
  const inputYenPrice = getBidInputYenPrice(inputAmount, currency, websiteRate);
  const actualYenPrice = getActualBidPrice(inputYenPrice, product, storeBidPriceMode);
  if (currency !== 'cny') {
    return {
      inputYenPrice,
      actualYenPrice,
      actualCnyAmount: 0
    };
  }

  const inputCnyAmount = Number(inputAmount || 0);
  const actualCnyAmount = isStoreProduct(product) && storeBidPriceMode === 'tax_before'
    ? Number((inputCnyAmount * 1.1).toFixed(2))
    : inputCnyAmount;

  return {
    inputYenPrice,
    actualYenPrice,
    actualCnyAmount
  };
}
