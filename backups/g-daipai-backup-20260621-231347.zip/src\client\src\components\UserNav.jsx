import { useEffect, useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { Button, List, Popup, SearchBar, Toast } from 'antd-mobile';
import { getActingUsers, getClientSiteConfig } from '../utils/api';
import { runDeduped } from '../utils/requestDedupe';
import { applyClientTheme, colors, getClientTheme, themeOptions } from '../styles';

const items = [
  { to: '/submit', label: '提交任务' },
  { to: '/bidding', label: '入札中' },
  { to: '/won', label: '落札商品' },
  { to: '/stats', label: '统计页面' }
];

const levelLabels = {
  1: '普通用户',
  2: '代理用户',
  3: '管理员'
};

function emitActingUserChange(user) {
  window.dispatchEvent(new CustomEvent('acting-user-change', { detail: user }));
}

function saveActingUser(user) {
  localStorage.setItem('actingUserId', String(user.id));
  localStorage.setItem('actingUsername', user.username);
  localStorage.setItem('actingUserBidStrategyScope', user.bid_strategy_scope || 'all');
}

export default function UserNav() {
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [selectedId, setSelectedId] = useState(localStorage.getItem('actingUserId') || '');
  const [pickerVisible, setPickerVisible] = useState(false);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [siteConfig, setSiteConfig] = useState({ noticeText: '', noticeMarquee: false });
  const [themeName, setThemeName] = useState(getClientTheme());

  async function loadActingUsers() {
    try {
      const res = await runDeduped('UserNav:getActingUsers', getActingUsers);
      const list = res.data?.data || [];
      setUsers(list);
      if (!list.length) return;

      const savedId = localStorage.getItem('actingUserId');
      const selected = list.find(user => String(user.id) === String(savedId)) || list[0];
      saveActingUser(selected);
      setSelectedId(String(selected.id));
      emitActingUserChange(selected);
    } catch (e) {
      Toast.show({ content: e.response?.data?.error || '账号列表加载失败' });
    }
  }

  useEffect(() => {
    loadActingUsers();
    getClientSiteConfig()
      .then(res => {
        setSiteConfig({
          noticeText: res.data?.noticeText || '',
          noticeMarquee: Boolean(res.data?.noticeMarquee)
        });
      })
      .catch(() => {});
  }, []);

  const selectedUser = users.find(user => String(user.id) === String(selectedId));
  const showSwitcher = users.length > 1 || Number(selectedUser?.user_level || localStorage.getItem('userLevel') || 1) >= 3;
  const normalizedKeyword = searchKeyword.trim().toLowerCase();
  const filteredUsers = normalizedKeyword
    ? users.filter(user => {
      const label = `${user.username || ''} ${levelLabels[user.user_level] || ''}`.toLowerCase();
      return label.includes(normalizedKeyword);
    })
    : users;

  function selectUser(nextId) {
    const user = users.find(item => String(item.id) === String(nextId));
    if (!user) return;
    saveActingUser(user);
    setSelectedId(String(user.id));
    emitActingUserChange(user);
  }

  function closeUserPicker() {
    setPickerVisible(false);
    setSearchKeyword('');
  }

  function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    localStorage.removeItem('userLevel');
    localStorage.removeItem('actingUserId');
    localStorage.removeItem('actingUsername');
    localStorage.removeItem('actingUserBidStrategyScope');
    navigate('/login', { replace: true });
  }

  function changeTheme(nextTheme) {
    const applied = applyClientTheme(nextTheme);
    setThemeName(applied);
  }

  return (
    <>
      <style>
        {`
          @keyframes clientNoticeMarquee {
            0% { transform: translateX(100%); }
            100% { transform: translateX(-100%); }
          }
        `}
      </style>

      <div
        style={{
          margin: '-20px -20px 14px',
          padding: siteConfig.noticeText ? '16px 20px 14px' : '10px 20px 0',
          background: colors.card,
          borderBottom: `1px solid ${colors.border}`,
          boxShadow: `0 6px 18px ${colors.shadow}`
        }}
      >
        {siteConfig.noticeText && (
          <div
            style={{
              border: `1px solid ${colors.border}`,
              background: colors.noticeBg,
              color: colors.accent,
              borderRadius: 8,
              minHeight: 38,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              overflow: 'hidden',
              boxShadow: `0 3px 10px ${colors.shadow}`
            }}
          >
            <div style={{ width: '100%', overflow: 'hidden', whiteSpace: 'nowrap', fontSize: 15, fontWeight: 600, textAlign: 'center' }}>
              <span
                style={{
                  display: 'inline-block',
                  padding: '0 16px',
                  animation: siteConfig.noticeMarquee ? 'clientNoticeMarquee 14s linear infinite' : 'none'
                }}
              >
                {siteConfig.noticeText}
              </span>
            </div>
          </div>
        )}
      </div>

      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: 10,
          padding: '0 2px'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ fontSize: 14, color: colors.muted }}>
            登录用户：<span style={{ fontWeight: 700, color: colors.text }}>{localStorage.getItem('username') || '-'}</span>
          </div>
          <Button size="mini" fill="outline" color="primary" onClick={logout}>退出</Button>
        </div>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 13, color: colors.muted }}>
            <span>风格</span>
            <select
              value={themeName}
              onChange={event => changeTheme(event.target.value)}
              style={{
                height: 28,
                minWidth: 82,
                border: `1px solid ${colors.borderStrong}`,
                borderRadius: 7,
                color: colors.text,
                background: colors.card,
                padding: '0 6px',
                fontSize: 13,
                outline: 'none'
              }}
            >
              {themeOptions.map(option => (
                <option key={option.value} value={option.value}>{option.label}</option>
              ))}
            </select>
          </label>
        </div>
      </div>

      {showSwitcher && (
        <div
          onClick={() => {
            setSearchKeyword('');
            setPickerVisible(true);
          }}
          style={{
            marginBottom: 10,
            padding: '10px 12px',
            borderRadius: 8,
            background: colors.card,
            border: `1px solid ${colors.border}`,
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            fontSize: 14,
            boxShadow: `0 3px 12px ${colors.shadow}`
          }}
        >
          <span style={{ color: colors.muted }}>当前账号</span>
          <span style={{ fontWeight: 700, color: colors.accent }}>{selectedUser?.username || localStorage.getItem('actingUsername') || '-'}</span>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8, marginBottom: 12 }}>
        {items.map(item => (
          <NavLink
            key={item.to}
            to={item.to}
            style={({ isActive }) => ({
              textAlign: 'center',
              textDecoration: 'none',
              borderRadius: 8,
              padding: '9px 6px',
              fontSize: 14,
              fontWeight: 600,
              color: isActive ? '#fff' : colors.text,
              background: isActive ? colors.accent : colors.card,
              border: `1px solid ${isActive ? colors.accent : colors.border}`,
              boxShadow: isActive ? `0 6px 14px ${colors.buttonShadow}` : `0 3px 10px ${colors.shadow}`
            })}
          >
            {item.label}
          </NavLink>
        ))}
      </div>

      <Popup
        visible={pickerVisible}
        onMaskClick={closeUserPicker}
        bodyStyle={{
          borderTopLeftRadius: 12,
          borderTopRightRadius: 12,
          maxHeight: '70vh',
          overflow: 'hidden'
        }}
      >
        <div style={{ padding: 12, borderBottom: '1px solid #f0f0f0' }}>
          <SearchBar
            placeholder="搜索用户"
            value={searchKeyword}
            onChange={setSearchKeyword}
          />
        </div>
        <div style={{ maxHeight: '58vh', overflowY: 'auto' }}>
          {filteredUsers.length ? (
            <List>
              {filteredUsers.map(user => {
                const active = String(user.id) === String(selectedId);
                return (
                  <List.Item
                    key={user.id}
                    clickable
                    extra={active ? '✓' : null}
                    onClick={() => {
                      selectUser(user.id);
                      closeUserPicker();
                    }}
                  >
                    <div style={{ fontWeight: active ? 700 : 500 }}>{user.username}</div>
                    <div style={{ fontSize: 12, color: '#999', marginTop: 3 }}>
                      {levelLabels[user.user_level] || '用户'}
                    </div>
                  </List.Item>
                );
              })}
            </List>
          ) : (
            <div style={{ padding: 24, textAlign: 'center', color: '#999' }}>未找到用户</div>
          )}
        </div>
      </Popup>
    </>
  );
}
